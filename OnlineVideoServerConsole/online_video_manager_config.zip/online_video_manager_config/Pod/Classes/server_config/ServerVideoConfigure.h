//
// Created by djzhang on 1/1/15.
// Copyright (c) 2015 djzhang. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString * const htdocs = @"/Volumes";

static NSString * const appProfile = @".AOnlineTutorial";
static NSString * const appCacheDirectory = @".cache";


@interface ServerVideoConfigure : NSObject


+ (NSArray *)youtubeArray;
+ (NSArray *)lyndaArray;
@end


@implementation ServerVideoConfigure {

}

+ (NSArray *)youtubeArray {
   return @[
    @"/Volumes/macshare/MacPE/youtubes",
    @"/Volumes/AppCache/TubeDownload",
   ];
}


+ (NSArray *)lyndaArray {
   return @[
    @"/Volumes/macshare/MacPE/Lynda.com",
   ];
}


@end